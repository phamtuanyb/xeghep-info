/**
 * Kho ảnh mặc định cho bài viết (CLAUDE.md Mục 12.B) — thư mục public/article-images.
 * Khi đăng/import bài, tự lấy NGẪU NHIÊN ảnh bìa + 1 ảnh trong bài từ thư mục này.
 * Admin chỉ cần bỏ ảnh vào thư mục; số lượng tùy ý.
 */
import { readdirSync } from 'node:fs';
import path from 'node:path';

const DIR = path.join(process.cwd(), 'public', 'article-images');
const IMG_RE = /\.(jpe?g|png|webp|gif|avif)$/i;

/** Danh sách URL ảnh trong thư mục mặc định (đường dẫn phục vụ tĩnh). */
export function listArticleImages(): string[] {
  try {
    return readdirSync(DIR)
      .filter((f) => IMG_RE.test(f))
      .map((f) => `/article-images/${f}`);
  } catch {
    return [];
  }
}

/** Lấy ngẫu nhiên `n` ảnh (ưu tiên KHÁC NHAU; nếu thiếu thì cho phép lặp). */
export function pickRandomArticleImages(n: number): string[] {
  const all = listArticleImages();
  if (all.length === 0) return [];
  const shuffled = [...all].sort(() => Math.random() - 0.5);
  return Array.from({ length: n }, (_, i) => shuffled[i % shuffled.length]!);
}

/** Chèn 1 ảnh vào thân bài (sau đoạn <p> đầu, hoặc nối cuối) NẾU bài chưa có ảnh nào. */
export function insertBodyImageIfNone(html: string, imageUrl: string): string {
  if (!imageUrl || /<img\b/i.test(html)) return html;
  const fig = `<figure><img src="${imageUrl}" alt="" /></figure>`;
  const m = html.match(/<\/p>/i);
  if (m && m.index !== undefined) {
    const pos = m.index + m[0].length;
    return html.slice(0, pos) + fig + html.slice(pos);
  }
  return html + fig;
}
